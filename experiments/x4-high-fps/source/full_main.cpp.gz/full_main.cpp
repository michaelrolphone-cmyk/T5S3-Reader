
#include <Arduino.h>
#include <driver/gpio.h>
#include <driver/spi_master.h>
#include <esp_attr.h>
#include <esp_err.h>
#include <esp_intr_alloc.h>
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include <soc/gpio_struct.h>

#include <algorithm>
#include <cstdint>
#include <cstring>

namespace {

constexpr gpio_num_t PIN_BTN_LEFT = GPIO_NUM_0;
constexpr gpio_num_t PIN_BTN_POWER = GPIO_NUM_3;
constexpr gpio_num_t PIN_BTN_RIGHT = GPIO_NUM_7;
constexpr gpio_num_t PIN_EPD_BUSY = GPIO_NUM_6;
constexpr gpio_num_t PIN_EPD_MOSI = GPIO_NUM_11;
constexpr gpio_num_t PIN_EPD_SCLK = GPIO_NUM_12;
constexpr gpio_num_t PIN_EPD_CS = GPIO_NUM_13;
constexpr gpio_num_t PIN_EPD_RST = GPIO_NUM_14;
constexpr gpio_num_t PIN_EPD_DC = GPIO_NUM_18;
constexpr gpio_num_t PIN_LIGHT_COOL = GPIO_NUM_8;
constexpr gpio_num_t PIN_LIGHT_WARM = GPIO_NUM_9;

constexpr uint16_t PANEL_WIDTH = 800;
constexpr uint16_t PANEL_HEIGHT = 480;
constexpr uint16_t CONTROLLER_HEIGHT = 600;
constexpr uint16_t GATE_OFFSET = 120;
constexpr uint16_t ROW_BYTES = PANEL_WIDTH / 8;
constexpr uint16_t SPI_ROWS_PER_CHUNK = 8;
constexpr size_t SPI_CHUNK_BYTES = ROW_BYTES * SPI_ROWS_PER_CHUNK;
constexpr int SPI_CLOCK_HZ = 20000000;
constexpr uint32_t BUSY_ASSERT_TIMEOUT_MS = 100;
constexpr uint32_t POWER_TIMEOUT_MS = 1500;
constexpr uint32_t REFRESH_TIMEOUT_MS = 3500;
constexpr uint8_t REQUIRED_LUT_ID_A = 0x68;
constexpr uint8_t REQUIRED_LUT_ID_B = 0x69;

constexpr uint8_t CMD_PANEL_SETTING = 0x00;
constexpr uint8_t CMD_PFS = 0x03;
constexpr uint8_t CMD_POWER_ON = 0x04;
constexpr uint8_t CMD_DTM1 = 0x10;
constexpr uint8_t CMD_DISPLAY_REFRESH = 0x12;
constexpr uint8_t CMD_DTM2 = 0x13;
constexpr uint8_t CMD_PLL = 0x30;
constexpr uint8_t CMD_VCOM_DATA_INTERVAL = 0x50;
constexpr uint8_t CMD_RESOLUTION = 0x61;
constexpr uint8_t CMD_GATE_SOURCE_START = 0x65;
constexpr uint8_t CMD_PARTIAL_WINDOW = 0x90;
constexpr uint8_t CMD_PARTIAL_IN = 0x91;
constexpr uint8_t CMD_PARTIAL_OUT = 0x92;
constexpr uint8_t CMD_CCSET = 0xE0;
constexpr uint8_t CMD_GATE_SCAN = 0xE1;
constexpr uint8_t CMD_TSSET = 0xE5;

constexpr uint8_t PSR_EXTERNAL = 0x37;
constexpr uint8_t PSR_OTP = 0x17;
constexpr uint8_t PSR_1 = 0x4D;
constexpr uint8_t PFS = 0x20;
constexpr uint8_t GATE_SCAN = 0x02;
constexpr uint8_t CCSET = 0x02;
constexpr uint8_t TSSET_FULL = 0x1E;
constexpr uint8_t TSSET_FAST = 0x5A;
constexpr uint8_t CDI_FULL = 0x97;
constexpr uint8_t CDI_FAST = 0xD7;
constexpr uint8_t PLL_STOCK = 0x0E;
constexpr uint8_t PLL_FAST = 0x0F;

constexpr uint8_t LUT_REGS[5] = {0x20, 0x21, 0x22, 0x23, 0x24};
constexpr size_t LUT_BYTES = 42;

// Xteink factory UC8279_aa_prebw_mid tables recovered by FreeInk. This is the
// known external-LUT control before the generated A2 experiments.
constexpr uint8_t STOCK_PREBW[5][LUT_BYTES] = {
    {0x01, 0x06, 0x01, 0x06, 0x06, 0x01, 0x01, 0x01, 0x02, 0x04, 0x00, 0x00, 0x01, 0x01},
    {0x01, 0x06, 0x81, 0x06, 0x06, 0x01, 0x01, 0x01, 0x02, 0x04, 0x00, 0x00, 0x01, 0x01},
    {0x01, 0x86, 0x81, 0x86, 0x86, 0x01, 0x01, 0x01, 0x82, 0x84, 0x00, 0x00, 0x01, 0x01},
    {0x01, 0x46, 0x41, 0x46, 0x46, 0x01, 0x01, 0x01, 0x42, 0x44, 0x00, 0x00, 0x01, 0x01},
    {0x01, 0x06, 0x01, 0x06, 0x06, 0x01, 0x01, 0x01, 0x02, 0x44, 0x00, 0x00, 0x01, 0x01},
};

enum class Waveform : uint8_t { OtpDu, StockPreBw, GeneratedA2 };

struct TestMode {
  const char* name;
  Waveform waveform;
  uint8_t pll;
  uint8_t drive_frames;
  uint8_t counter_frames;
  uint16_t window_y;
  uint16_t window_h;
  uint16_t frame_count;
};

constexpr TestMode MODES[] = {
    {"OTP DU / stock PLL / full 480 rows", Waveform::OtpDu, PLL_STOCK, 0, 0, 0, 480, 12},
    {"OTP DU / fast PLL / full 480 rows", Waveform::OtpDu, PLL_FAST, 0, 0, 0, 480, 12},
    {"OTP DU / fast PLL / 160-row band", Waveform::OtpDu, PLL_FAST, 0, 0, 160, 160, 20},
    {"Factory external PREBW / fast PLL / 160-row band", Waveform::StockPreBw, PLL_FAST, 0, 0, 160, 160, 20},
    {"Generated A2 / 8-frame pulse / 160-row band", Waveform::GeneratedA2, PLL_FAST, 8, 0, 160, 160, 24},
    {"Generated A2 / 4-frame pulse / 160-row band", Waveform::GeneratedA2, PLL_FAST, 4, 0, 160, 160, 24},
    {"Generated A2 / 2-frame pulse / 160-row band", Waveform::GeneratedA2, PLL_FAST, 2, 0, 160, 160, 24},
    {"Generated A2 / 1-frame pulse / 160-row band", Waveform::GeneratedA2, PLL_FAST, 1, 0, 160, 160, 24},
    {"Generated A2 / 4-frame pulse / full 480 rows", Waveform::GeneratedA2, PLL_FAST, 4, 0, 0, 480, 16},
};
constexpr size_t MODE_COUNT = sizeof(MODES) / sizeof(MODES[0]);
static_assert(MODE_COUNT <= 9, "single-key serial mode selection supports at most nine modes");
constexpr const char* LAB_VERSION = "0.1.0";

DRAM_ATTR volatile bool abort_requested = false;
DRAM_ATTR volatile uint32_t abort_pin = UINT32_MAX;
DRAM_ATTR volatile bool soft_stop_requested = false;

spi_device_handle_t spi_device = nullptr;
uint8_t* dma_buffer = nullptr;
bool screen_powered = false;
uint8_t panel_lut_id = 0;
size_t next_mode = 0;
uint32_t current_frame = 0;

void IRAM_ATTR hard_abort_isr(void* arg) {
  abort_pin = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(arg));
  abort_requested = true;
  // Stop command acceptance immediately. GPIOs are all below 32 on ESP32-S3.
  GPIO.out_w1tc.val = (1UL << PIN_EPD_RST) | (1UL << PIN_EPD_SCLK) | (1UL << PIN_EPD_MOSI) |
                      (1UL << PIN_EPD_DC);
  GPIO.out_w1ts.val = (1UL << PIN_EPD_CS);
}

[[noreturn]] void enter_abort_halt(const char* reason) {
  gpio_set_level(PIN_EPD_CS, 1);
  gpio_set_level(PIN_EPD_RST, 0);
  gpio_set_level(PIN_EPD_SCLK, 0);
  gpio_set_level(PIN_EPD_MOSI, 0);
  gpio_set_level(PIN_LIGHT_COOL, 0);
  gpio_set_level(PIN_LIGHT_WARM, 0);
  Serial.printf("\n[X4LAB] HARD ABORT: %s; pin=%lu. Panel reset is held LOW. Reboot to continue.\n", reason,
                static_cast<unsigned long>(abort_pin));
  Serial.flush();
  while (true) delay(1000);
}

inline void check_abort() {
  if (abort_requested) enter_abort_halt("physical/serial abort");
}

bool configure_output(gpio_num_t pin, int level) {
  gpio_config_t cfg{};
  cfg.pin_bit_mask = 1ULL << static_cast<unsigned>(pin);
  cfg.mode = GPIO_MODE_OUTPUT;
  cfg.pull_up_en = GPIO_PULLUP_DISABLE;
  cfg.pull_down_en = GPIO_PULLDOWN_DISABLE;
  cfg.intr_type = GPIO_INTR_DISABLE;
  if (gpio_config(&cfg) != ESP_OK) return false;
  return gpio_set_level(pin, level) == ESP_OK;
}

bool configure_input(gpio_num_t pin, gpio_pullup_t pullup, gpio_int_type_t interrupt) {
  gpio_config_t cfg{};
  cfg.pin_bit_mask = 1ULL << static_cast<unsigned>(pin);
  cfg.mode = GPIO_MODE_INPUT;
  cfg.pull_up_en = pullup;
  cfg.pull_down_en = GPIO_PULLDOWN_DISABLE;
  cfg.intr_type = interrupt;
  return gpio_config(&cfg) == ESP_OK;
}

void setup_abort_inputs() {
  configure_input(PIN_BTN_LEFT, GPIO_PULLUP_ENABLE, GPIO_INTR_NEGEDGE);
  configure_input(PIN_BTN_RIGHT, GPIO_PULLUP_ENABLE, GPIO_INTR_NEGEDGE);
  configure_input(PIN_BTN_POWER, GPIO_PULLUP_ENABLE, GPIO_INTR_DISABLE);
  esp_err_t err = gpio_install_isr_service(ESP_INTR_FLAG_IRAM);
  if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
    Serial.printf("[X4LAB] gpio_install_isr_service failed: %s\n", esp_err_to_name(err));
    enter_abort_halt("abort ISR unavailable");
  }
  if (gpio_isr_handler_add(PIN_BTN_LEFT, hard_abort_isr,
                           reinterpret_cast<void*>(static_cast<uintptr_t>(PIN_BTN_LEFT))) != ESP_OK ||
      gpio_isr_handler_add(PIN_BTN_RIGHT, hard_abort_isr,
                           reinterpret_cast<void*>(static_cast<uintptr_t>(PIN_BTN_RIGHT))) != ESP_OK) {
    enter_abort_halt("abort button setup failed");
  }
  if (gpio_get_level(PIN_BTN_LEFT) == 0 || gpio_get_level(PIN_BTN_RIGHT) == 0) {
    abort_pin = gpio_get_level(PIN_BTN_LEFT) == 0 ? PIN_BTN_LEFT : PIN_BTN_RIGHT;
    enter_abort_halt("side button held during boot");
  }
}

void bitbang_delay() {
  for (unsigned i = 0; i < 48; ++i) asm volatile("nop" ::: "memory");
}

void bitbang_write(uint8_t value) {
  for (int bit = 7; bit >= 0; --bit) {
    gpio_set_level(PIN_EPD_MOSI, (value >> bit) & 1U);
    gpio_set_level(PIN_EPD_SCLK, 1);
    bitbang_delay();
    gpio_set_level(PIN_EPD_SCLK, 0);
  }
}

uint8_t bitbang_read() {
  uint8_t value = 0;
  for (int bit = 0; bit < 8; ++bit) {
    bitbang_delay();
    value = static_cast<uint8_t>((value << 1) | (gpio_get_level(PIN_EPD_MOSI) ? 1U : 0U));
    gpio_set_level(PIN_EPD_SCLK, 1);
    bitbang_delay();
    gpio_set_level(PIN_EPD_SCLK, 0);
  }
  return value;
}

void read_controller_register(uint8_t command, uint8_t* out, size_t length) {
  configure_output(PIN_EPD_MOSI, 0);
  gpio_set_level(PIN_EPD_DC, 0);
  gpio_set_level(PIN_EPD_CS, 0);
  bitbang_write(command);
  gpio_set_level(PIN_EPD_DC, 1);
  configure_input(PIN_EPD_MOSI, GPIO_PULLUP_ENABLE, GPIO_INTR_DISABLE);
  bitbang_delay();
  for (size_t i = 0; i < length; ++i) out[i] = bitbang_read();
  gpio_set_level(PIN_EPD_CS, 1);
  configure_output(PIN_EPD_MOSI, 0);
}

bool wait_busy_high(uint32_t timeout_ms, const char* stage) {
  const int64_t deadline = esp_timer_get_time() + static_cast<int64_t>(timeout_ms) * 1000;
  while (gpio_get_level(PIN_EPD_BUSY) == 0) {
    check_abort();
    if (esp_timer_get_time() >= deadline) {
      Serial.printf("[X4LAB] timeout waiting BUSY_N high: %s\n", stage);
      return false;
    }
    delayMicroseconds(100);
  }
  return true;
}

bool probe_controller() {
  check_abort();
  configure_output(PIN_EPD_CS, 1);
  configure_output(PIN_EPD_DC, 0);
  configure_output(PIN_EPD_SCLK, 0);
  configure_output(PIN_EPD_MOSI, 0);
  configure_output(PIN_EPD_RST, 1);
  configure_input(PIN_EPD_BUSY, GPIO_PULLUP_DISABLE, GPIO_INTR_DISABLE);

  gpio_set_level(PIN_EPD_RST, 0);
  delay(50);
  check_abort();
  gpio_set_level(PIN_EPD_RST, 1);
  check_abort();
  delay(50);
  check_abort();
  if (!wait_busy_high(1000, "probe reset")) return false;

  uint8_t flag = 0;
  uint8_t version[5]{};
  uint8_t confirm_flag = 0;
  uint8_t confirm_version[5]{};
  read_controller_register(0x71, &flag, 1);
  read_controller_register(0x70, version, sizeof(version));
  delay(20);
  read_controller_register(0x71, &confirm_flag, 1);
  read_controller_register(0x70, confirm_version, sizeof(confirm_version));

  Serial.printf("[X4LAB] controller FLG=%02x VER=%02x %02x %02x %02x %02x BUSY_N=%d\n", flag, version[0],
                version[1], version[2], version[3], version[4], gpio_get_level(PIN_EPD_BUSY));
  if (flag != confirm_flag || memcmp(version, confirm_version, sizeof(version)) != 0) {
    Serial.println("[X4LAB] controller probe was not repeatable");
    return false;
  }
  panel_lut_id = version[2];
  if ((flag & 1U) == 0 || (panel_lut_id != REQUIRED_LUT_ID_A && panel_lut_id != REQUIRED_LUT_ID_B)) {
    Serial.printf("[X4LAB] REFUSING TEST: expected UC8279 ZHX LUT id 0x68/0x69, got 0x%02x\n", panel_lut_id);
    return false;
  }
  return true;
}

bool spi_transmit(const uint8_t* data, size_t length) {
  check_abort();
  if (!spi_device || !data || length == 0) return false;
  spi_transaction_t transaction{};
  transaction.length = length * 8;
  transaction.tx_buffer = data;
  const esp_err_t err = spi_device_polling_transmit(spi_device, &transaction);
  if (err != ESP_OK) {
    Serial.printf("[X4LAB] SPI transmit failed: %s\n", esp_err_to_name(err));
    return false;
  }
  check_abort();
  return true;
}

bool spi_transmit_byte(uint8_t value) {
  check_abort();
  spi_transaction_t transaction{};
  transaction.flags = SPI_TRANS_USE_TXDATA;
  transaction.length = 8;
  transaction.tx_data[0] = value;
  const esp_err_t err = spi_device_polling_transmit(spi_device, &transaction);
  if (err != ESP_OK) {
    Serial.printf("[X4LAB] SPI byte failed: %s\n", esp_err_to_name(err));
    return false;
  }
  check_abort();
  return true;
}

bool write_command(uint8_t command) {
  check_abort();
  gpio_set_level(PIN_EPD_DC, 0);
  gpio_set_level(PIN_EPD_CS, 0);
  if (abort_requested) {
    gpio_set_level(PIN_EPD_CS, 1);
    check_abort();
  }
  const bool ok = spi_transmit_byte(command);
  gpio_set_level(PIN_EPD_CS, 1);
  return ok;
}

bool write_data(const uint8_t* data, size_t length) {
  check_abort();
  gpio_set_level(PIN_EPD_DC, 1);
  gpio_set_level(PIN_EPD_CS, 0);
  if (abort_requested) {
    gpio_set_level(PIN_EPD_CS, 1);
    check_abort();
  }
  size_t offset = 0;
  bool ok = true;
  while (offset < length && ok) {
    const size_t count = std::min(length - offset, SPI_CHUNK_BYTES);
    memcpy(dma_buffer, data + offset, count);
    ok = spi_transmit(dma_buffer, count);
    offset += count;
  }
  gpio_set_level(PIN_EPD_CS, 1);
  return ok;
}

bool write_data_byte(uint8_t value) {
  check_abort();
  gpio_set_level(PIN_EPD_DC, 1);
  gpio_set_level(PIN_EPD_CS, 0);
  if (abort_requested) {
    gpio_set_level(PIN_EPD_CS, 1);
    check_abort();
  }
  const bool ok = spi_transmit_byte(value);
  gpio_set_level(PIN_EPD_CS, 1);
  return ok;
}

bool write_register(uint8_t command, const uint8_t* data, size_t length) {
  return write_command(command) && write_data(data, length);
}

bool write_register1(uint8_t command, uint8_t value) {
  return write_command(command) && write_data_byte(value);
}

bool initialize_spi() {
  spi_bus_config_t bus{};
  bus.mosi_io_num = PIN_EPD_MOSI;
  bus.miso_io_num = -1;
  bus.sclk_io_num = PIN_EPD_SCLK;
  bus.quadwp_io_num = -1;
  bus.quadhd_io_num = -1;
  bus.max_transfer_sz = SPI_CHUNK_BYTES;

  esp_err_t err = spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO);
  if (err != ESP_OK) {
    Serial.printf("[X4LAB] spi_bus_initialize failed: %s\n", esp_err_to_name(err));
    return false;
  }

  spi_device_interface_config_t device{};
  device.clock_speed_hz = SPI_CLOCK_HZ;
  device.mode = 0;
  device.spics_io_num = -1;
  device.queue_size = 1;
  err = spi_bus_add_device(SPI2_HOST, &device, &spi_device);
  if (err != ESP_OK) {
    Serial.printf("[X4LAB] spi_bus_add_device failed: %s\n", esp_err_to_name(err));
    return false;
  }

  dma_buffer = static_cast<uint8_t*>(heap_caps_malloc(SPI_CHUNK_BYTES, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL));
  if (!dma_buffer) {
    Serial.println("[X4LAB] DMA buffer allocation failed");
    return false;
  }
  return true;
}

bool controller_init(uint8_t pll) {
  gpio_set_level(PIN_EPD_RST, 0);
  delay(50);
  check_abort();
  gpio_set_level(PIN_EPD_RST, 1);
  check_abort();
  delay(50);
  check_abort();
  if (!wait_busy_high(1000, "controller reset")) return false;

  const uint8_t psr[] = {PSR_EXTERNAL, PSR_1};
  const uint8_t resolution[] = {static_cast<uint8_t>(PANEL_WIDTH >> 8), static_cast<uint8_t>(PANEL_WIDTH),
                                static_cast<uint8_t>(CONTROLLER_HEIGHT >> 8),
                                static_cast<uint8_t>(CONTROLLER_HEIGHT)};
  const uint8_t gate_start[] = {0, 0, 0, 0};
  if (!write_register(CMD_PANEL_SETTING, psr, sizeof(psr)) ||
      !write_register(CMD_RESOLUTION, resolution, sizeof(resolution)) ||
      !write_register(CMD_GATE_SOURCE_START, gate_start, sizeof(gate_start)) ||
      !write_register1(CMD_PFS, PFS) || !write_register1(CMD_PLL, pll) ||
      !write_register1(CMD_GATE_SCAN, GATE_SCAN)) {
    return false;
  }
  screen_powered = false;
  return true;
}

bool power_on() {
  if (screen_powered) return true;
  if (!write_command(CMD_POWER_ON)) return false;
  if (!wait_busy_high(POWER_TIMEOUT_MS, "power on")) return false;
  screen_powered = true;
  return true;
}

bool wait_refresh(uint32_t timeout_ms, uint32_t* duration_us) {
  const int64_t start = esp_timer_get_time();
  const int64_t assert_deadline = start + static_cast<int64_t>(BUSY_ASSERT_TIMEOUT_MS) * 1000;
  while (gpio_get_level(PIN_EPD_BUSY) != 0) {
    check_abort();
    if (esp_timer_get_time() >= assert_deadline) {
      Serial.println("[X4LAB] BUSY_N never asserted after DRF");
      return false;
    }
    delayMicroseconds(50);
  }
  const int64_t completion_deadline = start + static_cast<int64_t>(timeout_ms) * 1000;
  while (gpio_get_level(PIN_EPD_BUSY) == 0) {
    check_abort();
    if (esp_timer_get_time() >= completion_deadline) {
      Serial.println("[X4LAB] refresh timeout");
      return false;
    }
    delayMicroseconds(100);
  }
  if (duration_us) *duration_us = static_cast<uint32_t>(esp_timer_get_time() - start);
  return true;
}

uint8_t pattern_byte(uint32_t frame, uint16_t visible_y, uint16_t byte_x, uint16_t active_y, uint16_t active_h) {
  if (visible_y < active_y || visible_y >= active_y + active_h) return 0xFF;
  const uint16_t x0 = byte_x * 8;
  uint8_t value = 0xFF;
  for (uint8_t bit = 0; bit < 8; ++bit) {
    const uint16_t x = x0 + bit;
    const uint16_t shifted_x = static_cast<uint16_t>((x + frame * 24U) % PANEL_WIDTH);
    const bool checker = (((shifted_x / 32U) + ((visible_y - active_y) / 24U)) & 1U) == 0;
    const bool marker = visible_y < active_y + 16U && ((x / 16U) & 1U) == ((frame / 2U) & 1U);
    if (checker ^ marker) value &= static_cast<uint8_t>(~(0x80U >> bit));
  }
  return value;
}

bool stream_plane(uint8_t command, uint32_t frame, uint16_t active_y, uint16_t active_h) {
  if (!write_command(command)) return false;
  gpio_set_level(PIN_EPD_DC, 1);
  gpio_set_level(PIN_EPD_CS, 0);
  if (abort_requested) {
    gpio_set_level(PIN_EPD_CS, 1);
    check_abort();
  }

  uint16_t controller_row = 0;
  while (controller_row < CONTROLLER_HEIGHT) {
    check_abort();
    const uint16_t rows = std::min<uint16_t>(SPI_ROWS_PER_CHUNK, CONTROLLER_HEIGHT - controller_row);
    for (uint16_t local_row = 0; local_row < rows; ++local_row) {
      const uint16_t row = controller_row + local_row;
      uint8_t* destination = dma_buffer + static_cast<size_t>(local_row) * ROW_BYTES;
      if (row < GATE_OFFSET || row >= GATE_OFFSET + PANEL_HEIGHT) {
        memset(destination, 0xFF, ROW_BYTES);
      } else {
        const uint16_t visible_y = row - GATE_OFFSET;
        for (uint16_t x = 0; x < ROW_BYTES; ++x) {
          destination[x] = pattern_byte(frame, visible_y, x, active_y, active_h);
        }
      }
    }
    if (!spi_transmit(dma_buffer, static_cast<size_t>(rows) * ROW_BYTES)) {
      gpio_set_level(PIN_EPD_CS, 1);
      return false;
    }
    controller_row += rows;
  }
  gpio_set_level(PIN_EPD_CS, 1);
  return true;
}

bool stream_white_plane(uint8_t command) {
  if (!write_command(command)) return false;
  gpio_set_level(PIN_EPD_DC, 1);
  gpio_set_level(PIN_EPD_CS, 0);
  memset(dma_buffer, 0xFF, SPI_CHUNK_BYTES);
  size_t remaining = static_cast<size_t>(CONTROLLER_HEIGHT) * ROW_BYTES;
  while (remaining > 0) {
    check_abort();
    const size_t count = std::min(remaining, SPI_CHUNK_BYTES);
    if (!spi_transmit(dma_buffer, count)) {
      gpio_set_level(PIN_EPD_CS, 1);
      return false;
    }
    remaining -= count;
  }
  gpio_set_level(PIN_EPD_CS, 1);
  return true;
}

bool set_partial_window(uint16_t y, uint16_t height) {
  if (height == 0 || y + height > PANEL_HEIGHT) return false;
  const uint16_t x_end = PANEL_WIDTH - 1;
  const uint16_t y_start = GATE_OFFSET + y;
  const uint16_t y_end = y_start + height - 1;
  const uint8_t window[] = {0x00,
                            0x00,
                            static_cast<uint8_t>(x_end >> 8),
                            static_cast<uint8_t>(x_end | 0x07),
                            static_cast<uint8_t>(y_start >> 8),
                            static_cast<uint8_t>(y_start),
                            static_cast<uint8_t>(y_end >> 8),
                            static_cast<uint8_t>(y_end),
                            0x01};
  return write_command(CMD_PARTIAL_IN) && write_register(CMD_PARTIAL_WINDOW, window, sizeof(window));
}

void build_a2_lut(uint8_t out[5][LUT_BYTES], uint8_t drive_frames, uint8_t counter_frames) {
  memset(out, 0, 5 * LUT_BYTES);
  const uint8_t total = static_cast<uint8_t>(drive_frames + counter_frames);
  for (size_t table = 0; table < 5; ++table) {
    out[table][0] = 0x01;
    out[table][5] = 0x01;
    out[table][6] = 0x01;
  }
  // VCOM, unchanged-white, and unchanged-black remain at VSS for the same frame count.
  out[0][1] = total;
  out[1][1] = total;
  out[4][1] = total;
  // BW drives toward black (VSL), WB toward white (VSH). Optional second phase
  // is an intentionally short opposite-polarity compensation pulse.
  out[2][1] = static_cast<uint8_t>(0x80U | drive_frames);
  out[3][1] = static_cast<uint8_t>(0x40U | drive_frames);
  if (counter_frames != 0) {
    out[2][2] = static_cast<uint8_t>(0x40U | counter_frames);
    out[3][2] = static_cast<uint8_t>(0x80U | counter_frames);
  }
}

bool upload_lut(const TestMode& mode) {
  if (mode.waveform == Waveform::OtpDu) return true;
  if (mode.waveform == Waveform::StockPreBw) {
    for (size_t table = 0; table < 5; ++table) {
      if (!write_register(LUT_REGS[table], STOCK_PREBW[table], LUT_BYTES)) return false;
    }
    return true;
  }
  uint8_t generated[5][LUT_BYTES]{};
  build_a2_lut(generated, mode.drive_frames, mode.counter_frames);
  for (size_t table = 0; table < 5; ++table) {
    if (!write_register(LUT_REGS[table], generated[table], LUT_BYTES)) return false;
  }
  return true;
}

bool begin_refresh(const TestMode& mode, uint32_t* waveform_us) {
  if (!write_register1(CMD_PLL, mode.pll) || !set_partial_window(mode.window_y, mode.window_h) ||
      !write_register1(CMD_PFS, PFS) || !write_register1(CMD_GATE_SCAN, GATE_SCAN) ||
      !write_register1(CMD_VCOM_DATA_INTERVAL, CDI_FAST) || !write_register1(CMD_CCSET, CCSET) ||
      !write_register1(CMD_TSSET, TSSET_FAST)) {
    return false;
  }
  if (!power_on()) return false;

  const uint8_t psr[] = {mode.waveform == Waveform::OtpDu ? PSR_OTP : PSR_EXTERNAL, PSR_1};
  if (!write_register(CMD_PANEL_SETTING, psr, sizeof(psr)) || !upload_lut(mode) ||
      !write_command(CMD_DISPLAY_REFRESH)) {
    return false;
  }
  if (!wait_refresh(REFRESH_TIMEOUT_MS, waveform_us)) return false;
  return write_command(CMD_PARTIAL_OUT);
}

bool clean_baseline(uint16_t active_y, uint16_t active_h) {
  Serial.println("[X4LAB] establishing OTP full-clean baseline");
  if (!write_register1(CMD_PLL, PLL_STOCK) || !stream_white_plane(CMD_DTM1) ||
      !stream_plane(CMD_DTM2, 0, active_y, active_h) || !write_register1(CMD_VCOM_DATA_INTERVAL, CDI_FULL) ||
      !write_register1(CMD_CCSET, CCSET) || !write_register1(CMD_TSSET, TSSET_FULL) || !power_on()) {
    return false;
  }
  const uint8_t psr[] = {PSR_OTP, PSR_1};
  if (!write_register(CMD_PANEL_SETTING, psr, sizeof(psr)) || !write_command(CMD_DISPLAY_REFRESH)) return false;
  uint32_t waveform_us = 0;
  if (!wait_refresh(REFRESH_TIMEOUT_MS, &waveform_us)) return false;
  if (!stream_plane(CMD_DTM1, 0, active_y, active_h)) return false;
  current_frame = 0;
  Serial.printf("[X4LAB] clean baseline waveform=%lu us\n", static_cast<unsigned long>(waveform_us));
  return true;
}

bool run_mode(size_t index) {
  if (index >= MODE_COUNT) return false;
  const TestMode& mode = MODES[index];
  soft_stop_requested = false;
  while (gpio_get_level(PIN_BTN_POWER) == 0) {
    check_abort();
    delay(10);
  }
  Serial.printf("\n[X4LAB] MODE %u/%u: %s\n", static_cast<unsigned>(index + 1), static_cast<unsigned>(MODE_COUNT),
                mode.name);
  Serial.println("[X4LAB] EITHER SIDE BUTTON = IMMEDIATE HARD ABORT; power button = stop after current refresh");

  if (!clean_baseline(mode.window_y, mode.window_h)) return false;

  uint64_t sum_total = 0;
  uint64_t sum_waveform = 0;
  uint64_t sum_upload = 0;
  uint64_t sum_sync = 0;
  uint16_t completed = 0;
  for (uint16_t n = 0; n < mode.frame_count; ++n) {
    check_abort();
    if (gpio_get_level(PIN_BTN_POWER) == 0) soft_stop_requested = true;
    if (soft_stop_requested) break;

    const uint32_t next_frame = current_frame + 1;
    const int64_t frame_start = esp_timer_get_time();
    const int64_t upload_start = frame_start;
    if (!stream_plane(CMD_DTM2, next_frame, mode.window_y, mode.window_h)) return false;
    const uint32_t upload_us = static_cast<uint32_t>(esp_timer_get_time() - upload_start);

    uint32_t waveform_us = 0;
    if (!begin_refresh(mode, &waveform_us)) return false;

    const int64_t sync_start = esp_timer_get_time();
    if (!stream_plane(CMD_DTM1, next_frame, mode.window_y, mode.window_h)) return false;
    const uint32_t sync_us = static_cast<uint32_t>(esp_timer_get_time() - sync_start);
    const uint32_t total_us = static_cast<uint32_t>(esp_timer_get_time() - frame_start);
    current_frame = next_frame;

    sum_total += total_us;
    sum_waveform += waveform_us;
    sum_upload += upload_us;
    sum_sync += sync_us;
    ++completed;
    const uint32_t fps_x100 = total_us == 0 ? 0 : static_cast<uint32_t>(100000000ULL / total_us);
    Serial.printf("[X4LAB] frame=%u upload=%lu us wave=%lu us sync=%lu us total=%lu us fps=%lu.%02lu\n",
                  static_cast<unsigned>(n + 1), static_cast<unsigned long>(upload_us),
                  static_cast<unsigned long>(waveform_us), static_cast<unsigned long>(sync_us),
                  static_cast<unsigned long>(total_us), static_cast<unsigned long>(fps_x100 / 100),
                  static_cast<unsigned long>(fps_x100 % 100));
  }

  if (completed != 0) {
    const uint64_t average = sum_total / completed;
    const uint64_t fps_x100 = average == 0 ? 0 : 100000000ULL / average;
    Serial.printf("[X4LAB] RESULT mode=%u frames=%u avg_upload=%llu us avg_wave=%llu us avg_sync=%llu us "
                  "avg_total=%llu us avg_fps=%llu.%02llu\n",
                  static_cast<unsigned>(index + 1), static_cast<unsigned>(completed), sum_upload / completed,
                  sum_waveform / completed, sum_sync / completed, average, fps_x100 / 100, fps_x100 % 100);
  } else {
    Serial.printf("[X4LAB] mode=%u stopped before first frame\n", static_cast<unsigned>(index + 1));
  }
  while (gpio_get_level(PIN_BTN_POWER) == 0) delay(10);
  return true;
}

bool consume_power_press() {
  static bool previous = true;
  static int64_t changed_at = 0;
  const bool current = gpio_get_level(PIN_BTN_POWER) != 0;
  const int64_t now = esp_timer_get_time();
  bool pressed = false;
  if (current != previous && now - changed_at > 30000) {
    changed_at = now;
    previous = current;
    pressed = !current;
  }
  return pressed;
}

void poll_serial() {
  while (Serial.available()) {
    const int c = Serial.read();
    if (c == 'q' || c == 'Q' || c == 'x' || c == 'X') {
      abort_pin = 0xFE;
      abort_requested = true;
      check_abort();
    }
    if (c == 'n' || c == 'N' || c == ' ') {
      if (!run_mode(next_mode)) enter_abort_halt("test mode failed");
      next_mode = (next_mode + 1) % MODE_COUNT;
      Serial.printf("[X4LAB] ready; next mode %u. Press POWER or send n.\n", static_cast<unsigned>(next_mode + 1));
    }
    if (c >= '1' && c <= '0' + static_cast<int>(MODE_COUNT)) {
      const size_t selected = static_cast<size_t>(c - '1');
      if (!run_mode(selected)) enter_abort_halt("selected test mode failed");
      next_mode = (selected + 1) % MODE_COUNT;
      Serial.printf("[X4LAB] ready; next mode %u. Press POWER or send n.\n", static_cast<unsigned>(next_mode + 1));
    }
  }
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.printf("\n[X4LAB] Xteink X4 Pro UC8279 high-FPS standalone laboratory firmware v%s\n", LAB_VERSION);
  Serial.println("[X4LAB] LEFT OR RIGHT SIDE BUTTON: immediate controller reset + permanent halt");
  Serial.println("[X4LAB] POWER: start next mode; during a mode, request stop after current refresh");

  configure_output(PIN_LIGHT_COOL, 0);
  configure_output(PIN_LIGHT_WARM, 0);
  configure_output(PIN_EPD_CS, 1);
  configure_output(PIN_EPD_DC, 0);
  configure_output(PIN_EPD_SCLK, 0);
  configure_output(PIN_EPD_MOSI, 0);
  configure_output(PIN_EPD_RST, 0);
  setup_abort_inputs();

  if (!probe_controller()) enter_abort_halt("wrong/unknown display controller");
  if (!initialize_spi()) enter_abort_halt("SPI initialization failed");
  if (!controller_init(PLL_STOCK)) enter_abort_halt("controller initialization failed");
  if (!clean_baseline(160, 160)) enter_abort_halt("initial clean baseline failed");

  Serial.printf("[X4LAB] armed for UC8279 LUT id 0x%02x at %d MHz SPI.\n", panel_lut_id, SPI_CLOCK_HZ / 1000000);
  Serial.printf("[X4LAB] %u modes available. Press POWER or send n; send 1-%u to select; q aborts.\n",
                static_cast<unsigned>(MODE_COUNT), static_cast<unsigned>(MODE_COUNT));
}

void loop() {
  check_abort();
  poll_serial();
  if (consume_power_press()) {
    if (!run_mode(next_mode)) enter_abort_halt("test mode failed");
    next_mode = (next_mode + 1) % MODE_COUNT;
    Serial.printf("[X4LAB] ready; next mode %u. Press POWER or send n.\n", static_cast<unsigned>(next_mode + 1));
  }
  delay(5);
}

